import tkinter as tk
from tkinter import scrolledtext
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import requests
from bs4 import BeautifulSoup

class SentimentAnalyzer(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Sentiment Analyzer")
        self.geometry("400x400")
        
        # Label and entry for URL input
        self.label_url = tk.Label(self, text="Enter URL:")
        self.label_url.pack()
        self.entry_url = tk.Entry(self, width=40)
        self.entry_url.pack()

        # Button to fetch URL content and trigger sentiment analysis
        self.button_fetch = tk.Button(self, text="Fetch Content", command=self.fetch_and_analyze)
        self.button_fetch.pack()

        # Text box to display fetched content
        self.text_box = scrolledtext.ScrolledText(self, width=40, height=10, wrap=tk.WORD)
        self.text_box.pack()

        # Label to display sentiment analysis result
        self.label_result = tk.Label(self, text="")
        self.label_result.pack()

    def fetch_and_analyze(self):
        url = self.entry_url.get()
        if not url.strip():
            self.label_result.config(text="Please enter a URL.")
            return

        try:
            response = requests.get(url)
            response.raise_for_status()
            soup = BeautifulSoup(response.content, 'html.parser')
            article_text = ''
            for paragraph in soup.find_all('p'):
                article_text += paragraph.text.strip() + ' '
            self.text_box.delete(1.0, tk.END)
            self.text_box.insert(tk.END, article_text)
            self.label_result.config(text="Content fetched successfully.")

            # Perform sentiment analysis
            compound_score, sentiment_label = self.analyze_text(article_text)

            # Display sentiment analysis result
            result_message = f"Compound Score: {compound_score}\nSentiment Label: {sentiment_label}"
            self.label_result.config(text=result_message)
        except Exception as e:
            self.label_result.config(text=f"Error fetching or analyzing content: {e}")

    def analyze_text(self, text):
        analyzer = SentimentIntensityAnalyzer() 
        sentiment_score = analyzer.polarity_scores(text)
        compound_score = sentiment_score['compound']
        sentiment_label = "positive" if compound_score >= 0 else "negative"
        return compound_score, sentiment_label

def main():
    # Create and run the sentiment analyzer app
    app = SentimentAnalyzer()
    app.mainloop()

if __name__ == "__main__":
    main()
